# redisframework
a demo that shows how to implement a 'second kill' using redis distributed lock.
